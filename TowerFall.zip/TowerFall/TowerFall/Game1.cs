﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using Spline;
using System.Linq;

namespace TowerFall
{

    enum GameState
    {
        Menu, Play, End,
    }

    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D spriteSheet, explosion;
        List<GameObject> gameList;
        List<Vector2> posList, grassPosList, roadPosList, towerHUDList;
        List<Rectangle> roadRectList;
        List<Texture2D> textures;
        List<Bullet> bulletList;
        Rectangle roadRect, bulletRect;
        TowerObject towerO;
        RoadObject roadO;
        EnemyObject enemyO;
        GrassObject grassO;
        ParticleEngine particleEngine;
        Bullet bullet;
        TowerManager towerM; //Manager för torn
        WaveManager waveM; //Manager för waves av fiender, hur många etc
        Vector2 pos, fontHPPos, fontCoinsPos;
        SpriteFont spriteFont;
        GameState gameState;
        String[] printLevel;
        String getLine, HPText, coinsText, WaveText;
        bool movingDown, movingUp, movingLeft, movingRight, killBullet;
        public SimplePath path; //Spline path
        int groundX, groundY, activeSplineX, activeSplineY, bulletDamage, HP; //activeSpline används i min spline algoritm 
        char textLetter;
        public int levels, currentLevel, coins;
        public MouseState mouseState, oldMouseState;



        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            IsMouseVisible = true;
            Content.RootDirectory = "Content";
            fontHPPos = new Vector2(20, 20);
            fontCoinsPos = new Vector2(20, 40);
            levels = 1; //Gjort för använding av flera banor

            printLevel = new String[levels];
            textures = new List<Texture2D>();
            bulletList = new List<Bullet>();
            gameList = new List<GameObject>();
            grassPosList = new List<Vector2>();
            roadPosList = new List<Vector2>();
            posList = new List<Vector2>();
            towerHUDList = new List<Vector2>();
            roadRectList = new List<Rectangle>();

            FileReader();   //Läser av filerna så att banan kan ritas ut
            graphics.PreferredBackBufferWidth = 1150;
            graphics.PreferredBackBufferHeight = 700;

        }

        protected override void Initialize()
        {

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteSheet = Content.Load<Texture2D>("spriteSheet");
            spriteFont = Content.Load<SpriteFont>("spriteFont");
            textures.Add(Content.Load<Texture2D>("explosion")); //Separat för partikeleffekt
            particleEngine = new ParticleEngine(textures, new Vector2(1000000, 1000000)); 
            towerM = new TowerManager(spriteSheet);
            path = new SimplePath(graphics.GraphicsDevice);
            path.Clean(); //För att inte ha spiral i spline
            gameState = GameState.Menu;
            HPText = "HP: " + HP;
            coinsText = "";
            activeSplineX = 75; //startvärdet, behövs ritas ut av någon anledning, man kan lösa detta med att i Spline ha roadRectList.Count <= 1 istället för roadRectList.Any()
            activeSplineY = 125;
            coins = 100;
            HP = 100;

            grassPosList = GetPos('-', currentLevel); 
            foreach (Vector2 pos in grassPosList)
            {
                grassO = new GrassObject(spriteSheet, pos);
                gameList.Add(grassO);
            }

            roadPosList = GetPos('r', currentLevel);
            foreach (Vector2 pos in roadPosList)
            {
                roadO = new RoadObject(spriteSheet, pos);
                gameList.Add(roadO);
                roadRect = new Rectangle((int)pos.X + 25, (int)pos.Y + 25, 50, 50);
                roadRectList.Add(roadRect); //La in det i en seperat lista för att kunna ha det som en counter samt se till att ingen roadRect missades vid spline ritningen
            }

            towerHUDList = GetPos(' ', currentLevel);
            foreach (Vector2 pos in towerHUDList)
            {
                towerM.TowerHUD(pos);
            }
            Spline(); //Spline algoritm
            waveM = new WaveManager(spriteSheet, this, towerM);
        }

        protected override void Update(GameTime gameTime)
        {
            oldMouseState = mouseState;
            mouseState = Mouse.GetState();
            HPText = "HP: " + HP;
            switch (gameState)
            {
                case (GameState.Menu):
                    if (mouseState.LeftButton == ButtonState.Pressed && oldMouseState.LeftButton == ButtonState.Released)
                    {
                        gameState = GameState.Play;
                    }
                    break;
                case (GameState.Play):
                    coinsText = "Coins: " + coins;
                    BuildTower();                     
                    waveM.Update(gameTime);
                    towerM.Update(gameTime, this);
                    particleEngine.Update();
                    

                    foreach (Bullet bullet in bulletList)
                    {
                        bullet.Update();
                        bulletRect = bullet.GetRect();
                        bulletDamage = bullet.GetDamage();
                        waveM.Shoot(bulletDamage, bulletRect, particleEngine);

                        if (killBullet)
                        {
                            bulletList.Remove(bullet);
                            killBullet = false;
                            break;
                        }
                    }
                    break;
            }


            base.Update(gameTime);
        }

        public void TakeDamage(int damage)
        {
            HP -= damage;
            if (HP <= 0)
            {
                gameState = GameState.End;
            }
        }
       
        public void CreateBullet(Vector2 shotPos, double direction, int damage)
        {
            bullet = new Bullet(spriteSheet, shotPos, direction, damage, this);
            bulletList.Add(bullet);
        }
        public void KillBullet()
        {
            killBullet = true;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            if (gameState == GameState.Play)
            {
                spriteBatch.Begin();

                foreach (GameObject gameO in gameList)
                {
                    gameO.Draw(spriteBatch);
                }
                foreach (Bullet bullet in bulletList)
                {
                    bullet.Draw(spriteBatch);
                }
                towerM.Draw(spriteBatch);
                waveM.Draw(spriteBatch);
                spriteBatch.DrawString(spriteFont, HPText, fontHPPos, Color.White);
                spriteBatch.DrawString(spriteFont, coinsText, fontCoinsPos, Color.White);
                particleEngine.Draw(spriteBatch);
                //path.Draw(spriteBatch); För att se hur spline ritas ut
                base.Draw(gameTime);

                spriteBatch.End();
            }

        }
        public void EndGame()
        {
            gameState = GameState.End;
        }

        public void FileReader()
        {
            for (int i = 0; i < 1; i++)
            {
                StreamReader file = new StreamReader("Map-lvl" + i + ".txt"); 
                while (!file.EndOfStream)
                {
                    getLine += file.ReadLine();
                }
                file.Close();
                printLevel[i] = getLine;
                getLine = "";

            }
        }

        public void BuildTower()
        {
            if (mouseState.LeftButton == ButtonState.Pressed && oldMouseState.LeftButton == ButtonState.Released)
            {
                foreach (Vector2 pos in roadPosList)
                {
                    for (int i = 0; i < towerM.towers; i++)
                    {
                        towerM.BuildTower(mouseState.X, mouseState.Y, mouseState, i, pos);
                    }
                }
            }

        }

        protected List<Vector2> GetPos(char getLetter, int currentLevel)
        { 
            posList.Clear();
            for (int i = 0; i < printLevel[currentLevel].Length; i++)
            {
                textLetter = printLevel[currentLevel][i];

                if (textLetter == getLetter)
                {
                    pos = new Vector2(groundX, groundY);
                    posList.Add(pos);
                    groundX += 50;
                }
                else if (textLetter == '|')
                {
                    groundX = 0;
                    groundY += 50;
                }
                else if (textLetter == '#')
                {
                    groundX = 0;
                    groundY = 0;
                }
                else
                {
                    groundX += 50;
                }
            }
            return posList;
        }

        public void Spline()
        { 
            while (roadRectList.Any())
            {
                foreach (Rectangle roadRect in roadRectList)
                {
                    if (roadRect.Contains(new Vector2(activeSplineX, activeSplineY + 50)) && !movingUp)
                    {
                        movingDown = true;
                        movingRight = false;
                        movingLeft = false;
                        activeSplineY += 50;
                        path.AddPoint(new Vector2(activeSplineX, activeSplineY));
                        roadRectList.Remove(roadRect);
                        break;

                    }
                    else
                    {
                        movingDown = false;
                    }

                    if (roadRect.Contains(new Vector2(activeSplineX + 50, activeSplineY)) && !movingLeft)
                    {
                        movingRight = true;
                        movingUp = false;
                        movingDown = false;
                        activeSplineX += 50;
                        path.AddPoint(new Vector2(activeSplineX, activeSplineY));
                        roadRectList.Remove(roadRect);
                        break;

                    }
                    else
                    {
                        movingLeft = false;
                    }

                    if (roadRect.Contains(new Vector2(activeSplineX, activeSplineY - 50)) && !movingDown)
                    {
                        movingUp = true;
                        movingLeft = false;
                        movingRight = false;
                        activeSplineY -= 50;
                        path.AddPoint(new Vector2(activeSplineX, activeSplineY));
                        roadRectList.Remove(roadRect);
                        break;
                    }
                    else
                    {
                        movingDown = false;
                    }

                    if (roadRect.Contains(new Vector2(activeSplineX - 50, activeSplineY)) && !movingRight)
                    {
                        movingLeft = true;
                        movingUp = false;
                        movingDown = false;
                        activeSplineX -= 50;
                        path.AddPoint(new Vector2(activeSplineX, activeSplineY));
                        roadRectList.Remove(roadRect);
                        break;
                    }
                    else
                    {
                        movingRight = false;
                    }
                }
            }
        }
    }
}
