﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Spline;

namespace TowerFall
{
    class EnemyObject
    {
        Texture2D spriteSheet;
        Rectangle baseRect, towerRect, enemyRectPos;
        Vector2 pos, endPos;
        SimplePath path;
        ParticleEngine particleEngine;
        int range, damage, hp, ID;
        float speed;
        public float posSpeed;

        public EnemyObject(Texture2D spriteSheet, int damage, int hp, int ID, Vector2 pos, Vector2 endPos)
        {
            this.spriteSheet = spriteSheet;
            this.damage = damage;
            this.pos = pos;
            this.endPos = endPos;
            this.hp = hp;
            this.ID = ID;
            posSpeed = 1;
            enemyRectPos = new Rectangle((int)pos.X - 10, (int)pos.Y - 20, 50, 50);
            baseRect = new Rectangle(2061, 1436, 110, 110);

            if (ID == 0)
            { 
                towerRect = new Rectangle(2070, 1580, 110, 100);
                speed = 3;
            }
            else
            {
                towerRect = new Rectangle(10000, 10000, 0, 0);
                speed = 2;
            }
        }

        public void Update(GameTime gameTime, Vector2 newPos, Game1 game, WaveManager waveM, TowerManager towerM)
        {
            pos = newPos;
            posSpeed += speed; //Gör så att fiender rör sig via spline
            enemyRectPos.X = (int)pos.X - 25;
            enemyRectPos.Y = (int)pos.Y - 20;

            towerM.enemyPos(pos); //Kollar position för enemy för att se om de är i range för towers

            if (enemyRectPos.Contains(endPos))
            {
                game.TakeDamage(damage);
                waveM.KillEnemy();
            }
            if (hp <= 0)
            {
                game.coins += 10 - 5 * ID; //Får coins när fiender dör
                waveM.KillEnemy();
            }
        }

        public bool GetHit(int damage, Rectangle bulletRect, Game1 game, ParticleEngine particleEngine)
        {
            if (bulletRect.Intersects(enemyRectPos))
            {
                particleEngine.EmitterLocation = new Vector2(enemyRectPos.X, enemyRectPos.Y); //Ritar ut effekter när fiender blir träffade
                hp -= damage;
                game.KillBullet();
                return true;
            }
            return false;
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Draw(spriteSheet, enemyRectPos, baseRect, Color.White);
            sb.Draw(spriteSheet, enemyRectPos, towerRect, Color.White);
        }
    }
}
