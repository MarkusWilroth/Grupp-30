﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TowerFall
{
    class RoadObject : GameObject
    {
        Rectangle roadSheet;

        public RoadObject(Texture2D spriteSheet, Vector2 pos) : base(spriteSheet)
        {
            this.pos = pos;
            this.spriteSheet = spriteSheet;
            roadSheet = new Rectangle(2638, 768, 50, 50);
        }
        public override void Update(GameTime gameTime)
        {

        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(spriteSheet, pos, roadSheet, Color.White);
        }
    }

}