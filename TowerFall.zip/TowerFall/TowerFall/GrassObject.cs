﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TowerFall
{
    class GrassObject : GameObject
    {
        Rectangle grassSheet, roadSheet;

        public GrassObject(Texture2D spriteSheet, Vector2 pos) : base(spriteSheet)
        {
            this.pos = pos;
            this.spriteSheet = spriteSheet;
            grassSheet = new Rectangle(2432, 768, 50, 50);
            roadSheet = new Rectangle(2688, 768, 50, 50);
        }
        public override void Update(GameTime gameTime)
        {

        }

        public override void Draw(SpriteBatch sb)
        {
            sb.Draw(spriteSheet, pos, grassSheet, Color.White);
        }
    }

}
