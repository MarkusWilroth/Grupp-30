﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using Spline;

namespace TowerFall
{
    class WaveManager
    {
        int waveCounter, enemyCounter, eliteCounter, timer;
        bool ongoingWave, enemyDown, killBullet;
        KeyboardState keyboardState, oldKeyboardState;
        EnemyObject enemyO;
        Texture2D spriteSheet;
        List<EnemyObject> enemyList;
        Queue<WaveManager> waves = new Queue<WaveManager>();
        Game1 game;
        TowerManager towerM;
        Vector2 pos, endPos;
        SimplePath path;

        public WaveManager(Texture2D spriteSheet, Game1 game, TowerManager towerM)
        {
            this.spriteSheet = spriteSheet;
            this.game = game;
            this.towerM = towerM;
            waveCounter = 0;
            enemyCounter = 0;
            eliteCounter = 0;
            ongoingWave = false;
            enemyList = new List<EnemyObject>();
            pos = game.path.GetPos(game.path.beginT);
            endPos = game.path.GetPos(game.path.endT);
        }

        public void Update(GameTime gameTime)
        {
            keyboardState = Keyboard.GetState();
            if (!(enemyList.Any()) && keyboardState.IsKeyDown(Keys.Enter) && oldKeyboardState.IsKeyUp(Keys.Enter))
            {
                startWave();
            }
            if (ongoingWave)
            {
                if (enemyCounter > 0)
                {
                    timer++;
                    if (timer >= 60)
                    { //Gör så att fiender inte spawnar samtidigt
                        SpawnEnemies();
                        timer = 0;
                    }
                }
                else
                {
                    ongoingWave = false;
                }
            }

            foreach (EnemyObject enemyO in enemyList)
            {
                enemyO.Update(gameTime, game.path.GetPos(enemyO.posSpeed), game, this, towerM); 
                if (enemyDown)
                {
                    enemyList.Remove(enemyO);
                    break;
                }
            }
            enemyDown = false;
            oldKeyboardState = keyboardState;
        }
        public void KillEnemy()
        {
            enemyDown = true;
        }
        public void Shoot(int damage, Rectangle shootRect, ParticleEngine particleEngine)
        {
            foreach (EnemyObject enemyO in enemyList)
            {
                killBullet = enemyO.GetHit(damage, shootRect, game, particleEngine); //Kollar ifall bullet träffar fiende
                if (killBullet)
                {
                    break;
                }
            }
        }

        public void SpawnEnemies()
        {
            eliteCounter++;
            if (eliteCounter >= 5)
            { //var femte fiende är en elite med bättre stats
                enemyO = new EnemyObject(spriteSheet, 10, 25, 0, pos, endPos); //damage avgör hur mycket skada den gör om fienden kommer igenom
                eliteCounter = 0;
            }
            else
            {
                enemyO = new EnemyObject(spriteSheet, 5, 15, 1, pos, endPos);
            }
            enemyList.Add(enemyO);
            enemyCounter--;
        }

        public void startWave()
        {
            enemyCounter = 5 + 3 * waveCounter; //Ökas med 3 fiender gånger wavecountern, alltså vilken wave man är på
            ongoingWave = true;
            waveCounter++;
            
            if (waveCounter >= 10)
            { //10 är hur många waves det är innan spelet är slut
                game.EndGame();
            }
        }

        public void Draw(SpriteBatch sb)
        {
            foreach (EnemyObject enemyO in enemyList)
            {
                enemyO.Draw(sb);
            }
        }

    }
}
